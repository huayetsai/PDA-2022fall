#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <cstring>
using namespace std;

int digitToInt(string c){
        
        return( stoi(c) - stoi("0") );
}

class TILE
{
public:
    int index;
    char tile_type;
    int x_BF, y_BF, x_RT, y_RT;
    TILE(char type ,int number ,int x_bf, int y_bf,int x_rt,int y_rt){
        tile_type = type;
        index = number;
        x_RT = x_rt;
        y_RT = y_rt;
        x_BF = x_bf;
        y_BF = y_bf;
    }
};

class POINT
{
public:
    int x;
    int y;
    int tile_x;
    int tile_y;
    POINT(){
        x = 0;
        y = 0;
        tile_x = 0;
        tile_y = 0;

    }
};

bool compare(TILE* s1, TILE* s2){
    return s1->y_BF > s2->y_BF;
}

bool compare2(TILE* s1, TILE* s2){
    return s1->y_BF < s2->y_BF;
}

bool compare3(TILE* s1, TILE* s2){
    return s1->index < s2->index;
}

void Insertion(vector<TILE*> &space_tile, vector<TILE*> &block_tile, int index, int x_BF, int y_BF, int x_RT, int y_RT)
{   

    vector<TILE*> deal_tile;

    /////////////////////////////////////////////找上tile
    int space_size = space_tile.size();

    for(int i = 0; i < space_size; i++){
        if((space_tile[i]->y_BF <= y_RT) && (space_tile[i]->y_RT) >= y_BF){
                        
            if((space_tile[i]->x_BF <= x_RT) && (space_tile[i]->x_RT) >= x_BF){
                    
                deal_tile.push_back(space_tile[i]);
            }

        }
    } 

    sort(deal_tile.begin(), deal_tile.end(), compare);     
    int deal_size = deal_tile.size();
        
    //cout << "deal總共點數量 :"<< deal_size << endl;
    //for(int i = 0; i < deal_size; i++){
    //    cout << "(" << deal_tile[i]->x_BF << " " << deal_tile[i]->y_BF << ")" << " " << "(" <<deal_tile[i]->x_RT << " " << deal_tile[i]->y_RT << ")" << endl;
    //}


    TILE *p_top_tile;
    TILE *p_down_tile;
    

        for(int i = 0; i < space_size; i++){
            if((space_tile[i]->x_BF <= x_BF) && (space_tile[i]->x_RT) > x_BF){
                        
                if((space_tile[i]->y_BF < y_RT) && (space_tile[i]->y_RT) >= y_RT){
                    
                    p_top_tile = space_tile[i];
                }

            }
        }
    //////////////////////////////////////////////找下tile
        for(int i = 0; i < space_size; i++){
            if((space_tile[i]->x_BF <= x_BF) && (space_tile[i]->x_RT) > x_BF){
                        
                if((space_tile[i]->y_BF <= y_BF) && (space_tile[i]->y_RT) > y_BF){

                    p_down_tile = space_tile[i];
                }

            }
        }
    
    //cout << "(" << p_top_tile->x_BF << " " << p_top_tile->y_BF << ")" << " " << "(" <<p_top_tile->x_RT << " " << p_top_tile->y_RT << ")" << endl;
    //cout << "(" << p_down_tile->x_BF << " " << p_down_tile->y_BF << ")" << " " << "(" <<p_down_tile->x_RT << " " << p_down_tile->y_RT << ")" << endl;

    /////////////////////////////////////////////判斷上下是否相同
    if(p_top_tile == p_down_tile){                        //////////////////////////////////////上下tile相同
        //cout << "我有進來0" << endl;
        if(y_RT == p_top_tile->y_RT){
            if(y_BF == p_top_tile->y_BF){                 //////////////////////不切
                //cout << "我有進來1" << endl;
            }
            else{                                         //////////////////////切新下
                //cout << "我有進來2" << endl;
                TILE* p_new_space_tile = new TILE('s', 0, p_top_tile->x_BF, p_top_tile->y_BF, p_top_tile->x_RT, y_BF);
                space_tile.push_back(p_new_space_tile);
                deal_tile.push_back(p_new_space_tile);
                p_top_tile->y_BF = y_BF;
            }

        }else{                                            //////////////////////切新上
            if(y_BF == p_top_tile->y_BF){
                //cout << "我有進來3" << endl;
                TILE* p_new_space_tile = new TILE('s', 0, p_top_tile->x_BF, y_RT, p_top_tile->x_RT, p_top_tile->y_RT);
                space_tile.push_back(p_new_space_tile);
                deal_tile.push_back(p_new_space_tile);
                p_top_tile->y_RT = y_RT;

            }else{                                        //////////////////////切新上新下
                //cout << "我有進來4" << endl;
                
                TILE* p_new_top_space_tile = new TILE('s', 0, p_top_tile->x_BF, y_RT, p_top_tile->x_RT, p_top_tile->y_RT);
                TILE* p_new_down_space_tile = new TILE('s', 0, p_top_tile->x_BF, p_top_tile->y_BF, p_top_tile->x_RT, y_BF);
                space_tile.push_back(p_new_top_space_tile);
                space_tile.push_back(p_new_down_space_tile);
                deal_tile.push_back(p_new_top_space_tile);
                deal_tile.push_back(p_new_down_space_tile);
                p_top_tile->y_BF = y_BF;
                p_top_tile->y_RT = y_RT;
                
            }

        }

                                                        ////////////////////////切中間
        if(p_top_tile->x_BF == x_BF){
            if(p_top_tile->x_RT == x_RT){                ///////////////////////不切 刪掉原本的
                //cout << "我有進來5" << endl;        
                vector<TILE*>::iterator space_it = std::find(space_tile.begin(), space_tile.end(), p_top_tile);
                if (space_it != space_tile.end()){
                    space_tile.erase(space_it);
                }
                vector<TILE*>::iterator deal_it = std::find(deal_tile.begin(), deal_tile.end(), p_top_tile);
                if (deal_it != deal_tile.end()){
                    deal_tile.erase(deal_it);
                }

            }
            else{                                     //////////////////////////切右
                //cout << "我有進來6" << endl;
            p_top_tile->x_BF = x_RT;
            p_top_tile->x_RT = p_top_tile->x_RT;


            }
        }else{
            if(p_top_tile->x_RT == x_RT){               //////////////////////////切左
                //cout << "我有進來7" << endl;
            p_top_tile->x_BF = p_top_tile->x_BF;
            p_top_tile->x_RT = x_BF;
            /*TILE * p_new_space_tile = new TILE('s', 0, p_top_tile->x_BF, y_BF, x_BF, y_RT);
            space_tile.push_back(p_new_space_tile);*/

            }else{                                      //////////////////////////切左跟右

                //cout << "我有進來8" << endl;
            TILE * p_left_space_tile = new TILE('s', 0, p_top_tile->x_BF, p_top_tile->y_BF, x_BF, p_top_tile->y_RT);
            p_top_tile->x_BF = x_RT;
            p_top_tile->x_RT = p_top_tile->x_RT;
            space_tile.push_back(p_left_space_tile);
            deal_tile.push_back(p_left_space_tile);

            }

        }
    }else{                                                   //////////////////////////////////////上下tile不同
        //cout << "我有進來00" << endl;
                                       
        if(y_RT == p_top_tile->y_RT){
            if(y_BF == p_down_tile->y_BF){                 //////////////////////不切
                //cout << "我有進來9" << endl;
            }
            else{                                         //////////////////////切新下
                //cout << "我有進來10" << endl;
                TILE* p_new_space_tile = new TILE('s', 0, p_down_tile->x_BF, p_down_tile->y_BF, p_down_tile->x_RT, y_BF);
                space_tile.push_back(p_new_space_tile);
                deal_tile.push_back(p_new_space_tile);
                p_down_tile->y_BF = y_BF;
            }

        }else{                                            //////////////////////切新上
            if(y_BF == p_down_tile->y_BF){
                //cout << "我有進來11" << endl;
                TILE* p_new_space_tile = new TILE('s', 0, p_top_tile->x_BF, y_RT, p_top_tile->x_RT, p_top_tile->y_RT);
                space_tile.push_back(p_new_space_tile);
                deal_tile.push_back(p_new_space_tile);
                p_top_tile->y_RT = y_RT;

            }else{                                        //////////////////////切新上新下
                //cout << "我有進來12" << endl;
                
                TILE* p_new_top_space_tile = new TILE('s', 0, p_top_tile->x_BF, y_RT, p_top_tile->x_RT, p_top_tile->y_RT);
                TILE* p_new_down_space_tile = new TILE('s', 0, p_down_tile->x_BF, p_down_tile->y_BF, p_down_tile->x_RT, y_BF);
                space_tile.push_back(p_new_top_space_tile);
                space_tile.push_back(p_new_down_space_tile);
                deal_tile.push_back(p_new_top_space_tile);
                deal_tile.push_back(p_new_down_space_tile);
                p_top_tile->y_RT = y_RT;
                p_down_tile->y_BF = y_BF;
                
            }

        }

        int deal_size = deal_tile.size();
        
        //cout << "deal總共點數量 :"<< deal_size << endl;
        //for(int i = 0; i < deal_size; i++){
        //cout << "(" << deal_tile[i]->x_BF << " " << deal_tile[i]->y_BF << ")" << " " << "(" <<deal_tile[i]->x_RT << " " << deal_tile[i]->y_RT << ")" << endl;
        //}

        for(int i = 0; i < deal_size; i++){
            if(deal_tile[i]->y_RT > y_BF && deal_tile[i]->y_BF < y_RT){
                if(deal_tile[i]->x_BF == x_BF){
                    if(deal_tile[i]->x_RT == x_RT){                ///////////////////////不切 刪掉原本的
                        
                        //cout << "我有進來5" << endl;        
                        vector<TILE*>::iterator it = std::find(space_tile.begin(), space_tile.end(), deal_tile[i]);
                        if (it != space_tile.end()){
                            space_tile.erase(it);
                        }
                        vector<TILE*>::iterator deal_it = std::find(deal_tile.begin(), deal_tile.end(), p_top_tile);
                        if (deal_it != deal_tile.end()){
                        deal_tile.erase(deal_it);
                    }

                    }
                    else{   
                                                          //////////////////////////切右
                        //cout << "我有進來6" << endl;
                    deal_tile[i]->x_BF = x_RT;
                    deal_tile[i]->x_RT = deal_tile[i]->x_RT;

                    }
                }else{
                    if(deal_tile[i]->x_RT == x_RT){               //////////////////////////切左
                        
                        //cout << "我有進來7" << endl;
                    deal_tile[i]->x_BF = deal_tile[i]->x_BF;
                    deal_tile[i]->x_RT = x_BF;


                    }else{                                      //////////////////////////切左跟右

                        //cout << "我有進來8" << endl;
                    TILE * p_left_space_tile = new TILE('s', 0, deal_tile[i]->x_BF, deal_tile[i]->y_BF, x_BF, deal_tile[i]->y_RT);
                    deal_tile[i]->x_BF = x_RT;
                    deal_tile[i]->x_RT = deal_tile[i]->x_RT;

                    space_tile.push_back(p_left_space_tile);
                    deal_tile.push_back(p_left_space_tile);


                    }
                }
            }
        }




    }
    deal_size = deal_tile.size();

    sort(deal_tile.begin(), deal_tile.end(), compare2);  

    /*cout << "deal總共點數量 :"<< deal_size << endl;
    for(int i = 0; i < deal_size; i++){
        cout << "(" << deal_tile[i]->x_BF << " " << deal_tile[i]->y_BF << ")" << " " << "(" <<deal_tile[i]->x_RT << " " << deal_tile[i]->y_RT << ")" << endl;
    }*/
                                                                           ///////////////////////合併
    for(int i = 0; i < deal_size; i++){
        for(int j = 0; j < deal_size; j++){
            if(deal_tile[i]->y_RT == deal_tile[j]->y_BF){                  ///////////////////////上相同 
                
                if((deal_tile[i]->x_BF == deal_tile[j]->x_BF) && (deal_tile[i]->x_RT == deal_tile[j]->x_RT)){
                    
                    deal_tile[i]->y_RT = deal_tile[j]->y_RT;
                    vector<TILE*>::iterator space_it = std::find(space_tile.begin(), space_tile.end(), deal_tile[j]);
                    if (space_it != space_tile.end()){
                        space_tile.erase(space_it);
                    }
                    vector<TILE*>::iterator deal_it = std::find(deal_tile.begin(), deal_tile.end(), deal_tile[j]);
                    if (deal_it != deal_tile.end()){
                        deal_tile.erase(deal_it);
                    }

                }

            }
        }
    }   

    TILE * new_block_tile = new TILE('b', index, x_BF, y_BF, x_RT, y_RT);
    block_tile.push_back(new_block_tile);
    /*
    deal_size = deal_tile.size();
        
    cout << "deal總共點數量 :"<< deal_size << endl;
    for(int i = 0; i < deal_size; i++){
        cout << "(" << deal_tile[i]->x_BF << " " << deal_tile[i]->y_BF << ")" << " " << "(" <<deal_tile[i]->x_RT << " " << deal_tile[i]->y_RT << ")" << endl;
    }                                                                 

    space_size = space_tile.size();
    cout << "space總共點數量 :"<< space_size << endl;
    for(int i = 0; i < space_size; i++){
        cout << "(" << space_tile[i]->x_BF << " " << space_tile[i]->y_BF << ")" << " " << "(" <<space_tile[i]->x_RT << " " << space_tile[i]->y_RT << ")" << endl;
    }

    int block_size = block_tile.size();
    cout << "block總共點數量 :"<< block_size << endl;
    for(int i = 0; i < block_size; i++){
        cout << "(" << block_tile[i]->x_BF << " " << block_tile[i]->y_BF << ")" << " " << "(" <<block_tile[i]->x_RT << " " << block_tile[i]->y_RT << ")" << endl;
    }

    */
}

void NeighborFind(vector<TILE*> &space_tile, vector<TILE*> &block_tile, TILE* target_tile, int &block_number, int &space_number){
    
    vector<TILE*> deal_tile;

    int space_size = space_tile.size();

    for(int i = 0; i < space_size; i++){
        if((space_tile[i]->y_BF <= target_tile->y_RT) && (space_tile[i]->y_RT) >= target_tile->y_BF){
                        
            if((space_tile[i]->x_BF <= target_tile->x_RT) && (space_tile[i]->x_RT) >= target_tile->x_BF){
                    
                deal_tile.push_back(space_tile[i]);
            }

        }
    } 

    int block_size = block_tile.size();

    for(int i = 0; i < block_size; i++){
        if((block_tile[i]->y_BF <= target_tile->y_RT) && (block_tile[i]->y_RT) >= target_tile->y_BF){
                        
            if((block_tile[i]->x_BF <= target_tile->x_RT) && (block_tile[i]->x_RT) >= target_tile->x_BF){
                
                if(block_tile[i]->index == target_tile->index){

                }
                else{

                deal_tile.push_back(block_tile[i]);

                }
            }

        }
    } 

    int deal_size = deal_tile.size();
    for(int i = 0; i < deal_size; i++){
        if((deal_tile[i]->x_BF == target_tile->x_RT) && (deal_tile[i]->y_BF == target_tile->y_RT)){
                //////////////////////右上
        }else if((deal_tile[i]->x_BF == target_tile->x_RT) && (deal_tile[i]->y_RT == target_tile->y_BF)){
                //////////////////////右下
        }else if((deal_tile[i]->x_RT == target_tile->x_BF) && (deal_tile[i]->y_RT == target_tile->y_BF)){
                //////////////////////左下
        }else if((deal_tile[i]->x_RT == target_tile->x_BF) && (deal_tile[i]->y_BF == target_tile->y_RT)){
                //////////////////////左上
        }
        else{
            if(deal_tile[i]->tile_type == 'b'){
                block_number = block_number + 1;
            }
            if(deal_tile[i]->tile_type == 's'){
                space_number = space_number + 1;
            }
        }

    }

}


int main(int argc, char* argv[])
{  
    ifstream FILEIN;
    FILEIN.open(argv[1], ios::in);

    int X_BOUND, Y_BOUND;

    vector<POINT> traget_point;

    vector<TILE*> space_tile;
    vector<TILE*> block_tile;

    if (!FILEIN.good())
    {
        cout << "Failed to open file.\n";
    }
    else{

        
        FILEIN >> X_BOUND >> Y_BOUND;

        TILE* first_s_tile = new TILE('s', 0, 0, 0, X_BOUND, Y_BOUND);
        space_tile.push_back(first_s_tile);

        string input_type;
        FILEIN >> input_type;
        
        while (!FILEIN.eof())                               
        {
            if (input_type == "P")
            {
                //cout << "我有進來 P " << endl;
                POINT temp_point;
                FILEIN >> temp_point.x >> temp_point.y;
                //cout << "輸入點資料" <<temp_point.x << " " << temp_point.y << endl;

                int space_size = space_tile.size();
                for(int i = 0; i < space_size; i++){
                    if((space_tile[i]->x_BF <= temp_point.x) && (space_tile[i]->x_RT) > temp_point.x){
                        
                        if((space_tile[i]->y_BF <= temp_point.y) && (space_tile[i]->y_RT) > temp_point.y){

                            temp_point.tile_x = space_tile[i]->x_BF;
                            temp_point.tile_y = space_tile[i]->y_BF;

                        }

                    }
                }
                

                int block_size = block_tile.size();
                for(int i = 0; i < block_size; i++){
                    if((block_tile[i]->x_BF <= temp_point.x) && (block_tile[i]->x_RT) > temp_point.x){
                        
                        if((block_tile[i]->y_BF <= temp_point.y) && (block_tile[i]->y_RT) > temp_point.y){

                            temp_point.tile_x = block_tile[i]->x_BF;
                            temp_point.tile_y = block_tile[i]->y_BF;

                        }

                    }
                }

                traget_point.push_back(temp_point);

            }else {
                //cout << "我有進來非P" << endl;

                int index;
                index = digitToInt(input_type);
                int temp_x, temp_y, temp_width, temp_height; 
                FILEIN >> temp_x >> temp_y >> temp_width >> temp_height ;
                //cout << "插入block資料" << temp_x << " " << temp_y << " " << temp_width << " " << temp_height << " " << endl;

                Insertion(space_tile, block_tile, index, temp_x, temp_y, temp_x + temp_width, temp_y + temp_height);
                
                
            }
            FILEIN >> input_type;
        }
        
    }

    int space_size = space_tile.size();
    int block_size = block_tile.size();
    int point_size = traget_point.size();

    sort(block_tile.begin(), block_tile.end(), compare3);

    ofstream FILEOUT;
    FILEOUT.open(argv[2],ios::out);
    if (!FILEOUT.good()) {
        cout << "Failed to open file.\n";
    } 
    else {

        /*FILEOUT << space_size + block_size << endl;
        FILEOUT << X_BOUND << " " << Y_BOUND << endl;
        for(int i = 0; i< block_size; i++){
            FILEOUT << "1" << " " << block_tile[i]->x_BF << " " << block_tile[i]->y_BF << " " << block_tile[i]->x_RT - block_tile[i]->x_BF << " " << block_tile[i]->y_RT - block_tile[i]->y_BF << endl;
        }
        for(int i = 0; i< space_size; i++){
            FILEOUT << "-1" << " " << space_tile[i]->x_BF << " " << space_tile[i]->y_BF << " " << space_tile[i]->x_RT - space_tile[i]->x_BF << " " << space_tile[i]->y_RT - space_tile[i]->y_BF << endl;
        }*/
        FILEOUT << space_size + block_size << endl;
        for(int i = 0; i < block_size; i++){

            int block_number = 0;
            int space_number = 0;
            NeighborFind(space_tile, block_tile, block_tile[i], block_number, space_number);
            FILEOUT << block_tile[i]->index << " " << block_number << " " << space_number << endl;
        }

        for(int i = 0; i < point_size; i++){
            FILEOUT << traget_point[i].tile_x << " " << traget_point[i].tile_y  << endl;
        }
    }
    FILEOUT.close();
    return 0;


}